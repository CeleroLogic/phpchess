<style>
.format p {
	padding-top: 0.5em;
	padding-bottom: 0.5em;
}
</style>

<div class="format">
	<h3 class="title_h3">PHPCHESS INSTALLATION - Finished</h3>

	<h3>Installation is finished</h3>
	
	<b>Please ensure the install directory and its contents are DELETED before you make the site public!</b>

	<p>
		You can find the phpChess admin area <a href="../admin/index.php">HERE.</a><br/>
		You can find your phpChess home page <a href="../index.php">HERE.</a>
	</p>
	
	<h3>Thank you for installing phpchess.</h3>
</div>