<h3 class="title_h3">PHPCHESS INSTALLATION - INSTRUCTIONS</h3>

<p>Thank you for selecting phpChess version 4.2. Looks like you are upgrading from a previouse version. Please follow these instructions:</p>

<ol>
	<li>Make a back-up of all your phpchess files currently on your server.</li>
	<li>Check that the bin directory is set to CHMOD 755</li>
	<li>Copy back the bin/config.php file from your back-up to the server overwriting the empty config.php file</li>
</ol>

<p>Given that you are at this step already we hope you read the readme file as step 1 might be impossible now.</p>



<form action="" method="POST">
	
	<input type="submit" name="next" value="Next">
	
</form>