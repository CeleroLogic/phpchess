<?php

  if(!defined('CHECK_PHPCHESS')){
    die("Hacking attempt");
    exit;
  }

?>

<table width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
	<tr>
		<td  id="header">
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				<tr>
				<td class="logo" width="320">
					<h1><a href="http://www.phpchess.com">phpChess-Chess at its best</a></h1>
				</td>
				</tr>
			</table>
	</td></tr>
</table>


